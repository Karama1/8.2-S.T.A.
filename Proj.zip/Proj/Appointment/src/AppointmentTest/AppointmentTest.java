package AppointmentTest;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;
import Appointment.Appointment;

class AppointmentTest {Date currentDate = new Date();
@Test
public void testTaskClass()
{
	Date testDate = new Date();
	Appointment appointment = new Appointment("11111",testDate,"test");
	assertTrue(appointment.getDate().equals(currentDate));
	assertTrue(appointment.getDescription().equals("test"));
	assertTrue(appointment.getID().equals("11111"));
	}
@Test
public void testApointmentClassTooLong() 
{
	@SuppressWarnings("deprecation")
	Date oldDate = new Date(2020,1,1);
	assertThrows(IllegalArgumentException.class,() -> 
	{
		new Appointment("12345678901",oldDate ,"123456789 10-11-12-13-14-15-16-17-18-19 20-21-22-23-24-25-26-27-28-29-30 31-32-33-34-35-36-37-38");
		}
	);
	}
@Test
public void testAppointmentIDTooLong() 
{
	Date tempDate = new Date();assertThrows(IllegalArgumentException.class,()->
	{
		new Appointment("11111111111",tempDate,"Test check for ID length");
		}
	);
	}
@Test
public void testDateAge() {@SuppressWarnings("deprecation")
Date oldDate = new Date(2020,1,1);
assertThrows(IllegalArgumentException.class,()->{new Appointment("55555",oldDate,"testing to see if it works");});}
@Test
public void descriptionLengthTest() 
{
	Date tempDate = new Date();assertThrows(IllegalArgumentException.class,()->
	{
		new Appointment("55555",tempDate,"123456789 10-11-12-13-14-15-16-17-18-19-20-21-23-24-25-26-27-28-29-30-31-32-34-35-36-37-38-39-40");});}
@Test
public void idNullCheck() {Date tempDate = new Date();
assertThrows(IllegalArgumentException.class,()->{new Appointment(null,tempDate,"Check for null ID");});}
@Test
public void DescriptionNullCheck() {Date tempDate = new Date();
assertThrows(IllegalArgumentException.class,()->{new Appointment("666666",tempDate,null);});}
@Test
public void nullDateCheck() {assertThrows(IllegalArgumentException.class,()->{new Appointment("55555",null,"Check test Date");});
}
}