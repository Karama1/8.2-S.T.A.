package AppointmentTest;
import Appointment.AppointmentService;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest 
{
	@Test
	public void AppointmentServiceAddTestException() 
	{
		AppointmentService appointment = new AppointmentService();
		appointment.add("1111111111");
		assertThrows(IllegalArgumentException.class,() -> {appointment.add("1111111111");});
		}
	@Test
	public void ContactServiceAddTest() 
	{
		AppointmentService appointment = new AppointmentService();
		appointment.add("222222222");
		boolean isthere = false;
		for ( int i = 0;i < appointment.getAppointmentService().size();i++)
		{
			if(appointment.getAppointmentService().get(i).getID().equals("222222222")) {isthere = true;}
			assertTrue(isthere == true);
			}
		}
	@Test
	public void appointmentServiceDeleteTest() {
		AppointmentService appointment = new AppointmentService();
		appointment.add("222222222");
		appointment.add("333333333");
		appointment.delete("333333333");
		boolean isgone = true; 
		for ( int i = 0; i < appointment.getAppointmentService().size(); i++)
		{
			if(appointment.getAppointmentService().get(i).getID().equals("44444444")) {isgone = false;}
			assertTrue(isgone == true);
			}
		}
	}
