package Appointment;
import java.util.Date;
public class Appointment 
{
	private String appointmentID;
	private Date date = new Date();
	private Date currentDate = new Date();
	private StringBuffer description = new StringBuffer(50);
	
	public Appointment (String id, Date date, String description) 
	{
		if ( id == null ||id.length() > 10) 
		{
			throw new IllegalArgumentException("Invalid ID");
			}
		if ( date == null ||date.before(currentDate) ) 
		{
			throw new IllegalArgumentException("Invalid Date");
			}
		if ( description == null ||description.length() > 50) 
		{
			throw new IllegalArgumentException("Invalid Desc");
			}
		this.appointmentID = id;this.date = date;
		this.description.append(description);
		}
	public Appointment (String id ) {if ( id.length() > 10 || id == null) 
	{
		throw new IllegalArgumentException("Invalid ID");
		}
	this.appointmentID = id;
	}
	public String getID() {return this.appointmentID;
	}
	public String getDescription() 
	{
		return this.description.toString();
		}
	public Date getDate() 
	{
		return this.date;
		}
public void setDescription() 
{
	this.description.setLength(0);
	this.description.append(description);
	}
@SuppressWarnings("deprecation")
public void setDate( int date, int month, int year) 
{
	this.date.setDate(date);
	this.date.setMonth(month);
	this.date.setYear(year);
	}
}