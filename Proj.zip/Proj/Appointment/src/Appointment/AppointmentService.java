package Appointment;

import java.util.ArrayList;
public class AppointmentService 
{
	private ArrayList<Appointment> appointment = new ArrayList<Appointment>();
	
	public void add(String id)
	{
		Appointment temp = new Appointment(id);
		boolean check = false;
		for (int i = 0; i < appointment.size(); i++)
		{
			if ( appointment.get(i).getID().equals(id)){check = true;
			}
			}
		if ( check == true){throw new IllegalArgumentException("ID Exist");
		}
		else {appointment.add(temp);}
		}
	public void delete(String id){for ( int i = 0; i < appointment.size(); i++)
	{
		if (appointment.get(i).getID().equals(id)){appointment.remove(i);
		}
		}
	}
	public ArrayList<Appointment> getAppointmentService()
	{
		return this.appointment;
		}
	}
