import org.junit.Test;

public class TaskTest {

  @Test public void createValidTaskData() {
      Task task = new Task("1111111111", "Reading", "Read novelty book");
      System.out.println(task);
   }
   
}
