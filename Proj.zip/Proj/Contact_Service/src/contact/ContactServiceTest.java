package contact;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ContactServiceTest {

  
@Test
public void testAdd()
{
ContactService cs = new ContactService();
Contact test1 = new Contact("1111111", "Bob", "John", "9999999999", "Random Heart Appointment");
assertEquals(true, cs.addContact(test1));
}

@Test
public void testDelete()
{
   ContactService cs = new ContactService();
     
Contact test1 = new Contact("1111111", "Bob", "John", "9999999999", "Random Heart Appointment");
Contact test2 = new Contact("1234567", "Herckle", "Pennyes", "2187123404", "Hawaii of third");
Contact test3 = new Contact("3333333", "Jerry", "Springer", "9215501793", "123 fake street");

cs.addContact(test1);
cs.addContact(test2);
cs.addContact(test3);

assertEquals(true, cs.deleteContact("1111111"));
assertEquals(true, cs.deleteContact("1234567"));
assertEquals(true, cs.deleteContact("3333333"));
}

@Test
public void testUpdate()
{
ContactService cs = new ContactService();
     
Contact test1 = new Contact("1111111", "Bob", "John", "9999999999", "Random Heart Appointment");
Contact test2 = new Contact("1234567", "Herckle", "Pennyes", "2187123404", "Hawaii of third");
Contact test3 = new Contact("3333333", "Jerry", "Springer", "9215501793", "123 fake street");

cs.addContact(test1);
cs.addContact(test2);
cs.addContact(test3);

assertEquals(true, cs.updateContact("3333333", "Tompson", "Fordman", "9215501793", "123 fake street"));
assertEquals(false, cs.updateContact("9752322", "Jerriest", "Springtime", "9215501793", "123 fake street"));
}

}